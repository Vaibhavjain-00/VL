import { useMemo, useState } from "react";

function FunctionGenerator() {
  const [powerOn, setPowerOn] = useState(false);

  const [amplitude, setAmplitude] = useState(5);
  const [frequency, setFrequency] = useState(1);
  const [phase, setPhase] = useState(0);

  const [selectedTerminal, setSelectedTerminal] = useState(null);
  const [connections, setConnections] = useState([]);

  const [activeChannels, setActiveChannels] = useState({
    ch1: true,
    ch2: true,
    ch3: true,
  });

  /*
   * Fixed circuit terminals.
   * x and y are positions inside the circuit SVG.
   */
  const terminals = [
    { id: "T1", x: 90, y: 95 },
    { id: "T2", x: 90, y: 315 },

    { id: "T3", x: 230, y: 95 },
    { id: "T4", x: 230, y: 315 },

    { id: "T5", x: 350, y: 95 },
    { id: "T6", x: 350, y: 315 },

    { id: "T7", x: 500, y: 95 },
    { id: "T8", x: 500, y: 315 },

    { id: "T9", x: 650, y: 95 },
    { id: "T10", x: 650, y: 315 },

    { id: "T11", x: 770, y: 145 },
    { id: "T12", x: 770, y: 215 },
  ];

  /*
   * Generate node numbers.
   * Every connected pair gets the same number.
   */
  const nodeNumbers = useMemo(() => {
    const nodes = {};

    terminals.forEach((terminal, index) => {
      nodes[terminal.id] = null;
    });

    connections.forEach((connection, index) => {
      const number = index + 1;

      nodes[connection.from] = number;
      nodes[connection.to] = number;
    });

    return nodes;
  }, [connections]);

  const handleTerminalClick = (terminalId) => {
    if (!powerOn) {
      alert("Turn Power ON before connecting the circuit.");
      return;
    }

    if (!selectedTerminal) {
      setSelectedTerminal(terminalId);
      return;
    }

    if (selectedTerminal === terminalId) {
      setSelectedTerminal(null);
      return;
    }

    const alreadyConnected = connections.some(
      (connection) =>
        (connection.from === selectedTerminal &&
          connection.to === terminalId) ||
        (connection.from === terminalId &&
          connection.to === selectedTerminal)
    );

    if (!alreadyConnected) {
      setConnections([
        ...connections,
        {
          from: selectedTerminal,
          to: terminalId,
        },
      ]);
    }

    setSelectedTerminal(null);
  };

  const clearConnections = () => {
    setConnections([]);
    setSelectedTerminal(null);
  };

  const toggleChannel = (channel) => {
    setActiveChannels({
      ...activeChannels,
      [channel]: !activeChannels[channel],
    });
  };

  /*
   * Create waveform points.
   */
  const createWave = (type, verticalOffset) => {
    const points = [];

    for (let x = 0; x <= 760; x += 4) {
      const t = x / 760;

      const cycles = frequency * 2.5;

      const angle =
        2 * Math.PI * cycles * t +
        (phase * Math.PI) / 180;

      let value = 0;

      if (type === "sine") {
        value = Math.sin(angle);
      }

      if (type === "square") {
        value = Math.sin(angle) >= 0 ? 1 : -1;
      }

      if (type === "triangle") {
        value =
          2 *
            Math.abs(
              2 *
                ((cycles * t + phase / 360) %
                  1) -
                1
            ) -
          1;
      }

      const y =
        verticalOffset -
        value * amplitude * 5;

      points.push(`${x + 20},${y}`);
    }

    return points.join(" ");
  };

  const wave1 = createWave("square", 90);
  const wave2 = createWave("triangle", 190);
  const wave3 = createWave("sine", 290);

  return (
    <div className="function-generator-page">

      {/* =========================================
          TOP HEADER
          ========================================= */}

      <header className="fg-header">

        <div className="fg-menu">
          ☰
        </div>

        <div className="fg-logo">
          <div className="fg-logo-symbol">
            ⚗
          </div>

          <div>
            <strong>Virtual Labs</strong>
            <small>BIET Jhansi</small>
          </div>
        </div>

        <div className="fg-title">
          Function generator using operational amplifier
        </div>

        <div className="fg-rating">
          ★ ★ ★ ★ ☆
        </div>

        <button className="fg-header-button">
          Rate Me
        </button>

        <button className="fg-header-button">
          Report a Bug
        </button>

      </header>


      {/* ORANGE LINE */}

      <div className="fg-orange-line"></div>


      {/* =========================================
          MAIN SIMULATION
          ========================================= */}

      <main className="fg-main">

        {/* =====================================
            OSCILLOSCOPE
            ===================================== */}

        <section className="fg-panel oscilloscope-panel">

          <div className="fg-panel-title">
            OSCILLOSCOPE
          </div>

          <div className="scope-screen">

            <svg
              viewBox="0 0 800 360"
              className="scope-svg"
            >

              {/* Grid */}

              <defs>

                <pattern
                  id="scopeGrid"
                  width="40"
                  height="30"
                  patternUnits="userSpaceOnUse"
                >

                  <path
                    d="M 40 0 L 0 0 0 30"
                    fill="none"
                    stroke="#d9d9d9"
                    strokeWidth="1"
                  />

                </pattern>

              </defs>

              <rect
                width="800"
                height="360"
                fill="url(#scopeGrid)"
              />


              {/* Centre lines */}

              <line
                x1="20"
                y1="120"
                x2="780"
                y2="120"
                stroke="#c7c7c7"
              />

              <line
                x1="20"
                y1="240"
                x2="780"
                y2="240"
                stroke="#c7c7c7"
              />


              {/* Square */}

              {powerOn && activeChannels.ch1 && (

                <polyline
                  points={wave1}
                  fill="none"
                  stroke="#159b25"
                  strokeWidth="4"
                />

              )}


              {/* Triangle */}

              {powerOn && activeChannels.ch2 && (

                <polyline
                  points={wave2}
                  fill="none"
                  stroke="#244de8"
                  strokeWidth="4"
                />

              )}


              {/* Sine */}

              {powerOn && activeChannels.ch3 && (

                <polyline
                  points={wave3}
                  fill="none"
                  stroke="#f49b00"
                  strokeWidth="4"
                />

              )}

            </svg>


            {!powerOn && (

              <div className="scope-off">
                POWER OFF
              </div>

            )}

          </div>


          {/* Oscilloscope Controls */}

          <div className="scope-controls">

            <div className="scope-buttons">

              <button
                className={
                  activeChannels.ch1
                    ? "channel-button active-green"
                    : "channel-button"
                }
                onClick={() => toggleChannel("ch1")}
              >
                Channel 1
              </button>

              <button
                className={
                  activeChannels.ch2
                    ? "channel-button active-blue"
                    : "channel-button"
                }
                onClick={() => toggleChannel("ch2")}
              >
                Channel 2
              </button>

              <button
                className={
                  activeChannels.ch3
                    ? "channel-button active-orange"
                    : "channel-button"
                }
                onClick={() => toggleChannel("ch3")}
              >
                Channel 3
              </button>

              <button className="channel-button">
                Ground
              </button>

              <button className="channel-button">
                Dual
              </button>

            </div>


            <div className="scope-slider-row">

              <label>
                Amplitude
              </label>

              <input
                type="range"
                min="1"
                max="10"
                value={amplitude}
                onChange={(e) =>
                  setAmplitude(Number(e.target.value))
                }
              />

              <span>
                {amplitude} V
              </span>

            </div>


            <div className="scope-slider-row">

              <label>
                Frequency
              </label>

              <input
                type="range"
                min="1"
                max="10"
                value={frequency}
                onChange={(e) =>
                  setFrequency(Number(e.target.value))
                }
              />

              <span>
                {frequency} Hz
              </span>

            </div>


            <div className="scope-slider-row">

              <label>
                Phase
              </label>

              <input
                type="range"
                min="0"
                max="360"
                value={phase}
                onChange={(e) =>
                  setPhase(Number(e.target.value))
                }
              />

              <span>
                {phase}°
              </span>

            </div>


            <button
              className={
                powerOn
                  ? "power-button power-on"
                  : "power-button"
              }
              onClick={() => setPowerOn(!powerOn)}
            >
              Power: {powerOn ? "On" : "Off"}
            </button>

          </div>

        </section>


        {/* =====================================
            RIGHT SIDE
            ===================================== */}

        <div className="fg-right-column">


          {/* ===================================
              CIRCUIT
              =================================== */}

          <section className="fg-panel circuit-panel">

            <div className="fg-panel-title">
              CIRCUIT
            </div>


            <div className="circuit-workspace">

              <svg
                viewBox="0 0 850 380"
                className="circuit-svg"
              >

                {/* ==========================
                    POWER RAILS
                    ========================== */}

                <line
                  x1="40"
                  y1="70"
                  x2="810"
                  y2="70"
                  stroke="#222"
                  strokeWidth="3"
                />

                <line
                  x1="40"
                  y1="330"
                  x2="810"
                  y2="330"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="15"
                  y="65"
                  fontSize="15"
                >
                  V+
                </text>

                <text
                  x="15"
                  y="335"
                  fontSize="15"
                >
                  V−
                </text>


                {/* ==========================
                    OP AMP 1
                    ========================== */}

                <polygon
                  points="160,120 160,220 270,170"
                  fill="#ffffff"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="180"
                  y="168"
                  fontSize="14"
                  fontWeight="bold"
                >
                  LM741
                </text>

                <text
                  x="145"
                  y="145"
                  fontSize="18"
                >
                  −
                </text>

                <text
                  x="145"
                  y="205"
                  fontSize="18"
                >
                  +
                </text>


                {/* ==========================
                    RESISTOR 1
                    ========================== */}

                <rect
                  x="80"
                  y="135"
                  width="70"
                  height="20"
                  fill="#f5e4bd"
                  stroke="#8b6b32"
                  strokeWidth="2"
                />

                <text
                  x="88"
                  y="129"
                  fontSize="11"
                >
                  R1 100KΩ
                </text>


                {/* ==========================
                    OP AMP 2
                    ========================== */}

                <polygon
                  points="330,120 330,220 440,170"
                  fill="#ffffff"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="350"
                  y="168"
                  fontSize="14"
                  fontWeight="bold"
                >
                  LM741
                </text>

                <text
                  x="315"
                  y="145"
                  fontSize="18"
                >
                  −
                </text>

                <text
                  x="315"
                  y="205"
                  fontSize="18"
                >
                  +
                </text>


                {/* ==========================
                    CAPACITOR
                    ========================== */}

                <line
                  x1="300"
                  y1="95"
                  x2="300"
                  y2="145"
                  stroke="#222"
                  strokeWidth="3"
                />

                <line
                  x1="290"
                  y1="145"
                  x2="310"
                  y2="145"
                  stroke="#222"
                  strokeWidth="4"
                />

                <line
                  x1="290"
                  y1="155"
                  x2="310"
                  y2="155"
                  stroke="#222"
                  strokeWidth="4"
                />

                <line
                  x1="300"
                  y1="155"
                  x2="300"
                  y2="205"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="315"
                  y="145"
                  fontSize="11"
                >
                  C1
                </text>


                {/* ==========================
                    OP AMP 3
                    ========================== */}

                <polygon
                  points="500,120 500,220 610,170"
                  fill="#ffffff"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="520"
                  y="168"
                  fontSize="14"
                  fontWeight="bold"
                >
                  LM741
                </text>

                <text
                  x="485"
                  y="145"
                  fontSize="18"
                >
                  −
                </text>

                <text
                  x="485"
                  y="205"
                  fontSize="18"
                >
                  +
                </text>


                {/* ==========================
                    OP AMP 4
                    ========================== */}

                <polygon
                  points="650,120 650,220 760,170"
                  fill="#ffffff"
                  stroke="#222"
                  strokeWidth="3"
                />

                <text
                  x="670"
                  y="168"
                  fontSize="14"
                  fontWeight="bold"
                >
                  LM741
                </text>


                {/* ==========================
                    FEEDBACK WIRES
                    ========================== */}

                <path
                  d="M270 170 L270 280 L110 280 L110 155"
                  fill="none"
                  stroke="#333"
                  strokeWidth="2"
                />

                <path
                  d="M440 170 L440 300 L300 300"
                  fill="none"
                  stroke="#333"
                  strokeWidth="2"
                />


                {/* ==========================
                    OUTPUT LABELS
                    ========================== */}

                <text
                  x="780"
                  y="115"
                  fontSize="14"
                  fontWeight="bold"
                >
                  Square
                </text>

                <text
                  x="780"
                  y="170"
                  fontSize="14"
                  fontWeight="bold"
                >
                  Triangular
                </text>

                <text
                  x="780"
                  y="225"
                  fontSize="14"
                  fontWeight="bold"
                >
                  Sine
                </text>


                {/* ==========================
                    MANUAL CONNECTION WIRES
                    ========================== */}

                {connections.map((connection, index) => {

                  const from = terminals.find(
                    (terminal) =>
                      terminal.id === connection.from
                  );

                  const to = terminals.find(
                    (terminal) =>
                      terminal.id === connection.to
                  );

                  if (!from || !to) return null;

                  return (
                    <g key={index}>

                      <line
                        x1={from.x}
                        y1={from.y}
                        x2={to.x}
                        y2={to.y}
                        stroke="#e60000"
                        strokeWidth="4"
                      />

                    </g>
                  );

                })}


                {/* ==========================
                    TERMINALS
                    ========================== */}

                {terminals.map((terminal) => {

                  const selected =
                    selectedTerminal === terminal.id;

                  return (
                    <g
                      key={terminal.id}
                      onClick={() =>
                        handleTerminalClick(
                          terminal.id
                        )
                      }
                      style={{
                        cursor: "pointer",
                      }}
                    >

                      <circle
                        cx={terminal.x}
                        cy={terminal.y}
                        r={selected ? 9 : 7}
                        fill={
                          selected
                            ? "#00aaff"
                            : "#ff2020"
                        }
                        stroke="#ffffff"
                        strokeWidth="3"
                      />

                      {nodeNumbers[terminal.id] && (

                        <text
                          x={terminal.x + 8}
                          y={terminal.y - 8}
                          fontSize="12"
                          fontWeight="bold"
                          fill="#d00000"
                        >
                          N{nodeNumbers[terminal.id]}
                        </text>

                      )}

                    </g>
                  );

                })}

              </svg>


              <div className="connection-help">

                {selectedTerminal ? (
                  <>
                    Terminal <strong>{selectedTerminal}</strong>{" "}
                    selected. Click another terminal to connect.
                  </>
                ) : (
                  <>
                    Click any red terminal, then click another
                    terminal to connect them.
                  </>
                )}

              </div>


              <div className="circuit-actions">

                <button
                  className="clear-wire-button"
                  onClick={clearConnections}
                >
                  Clear Wires
                </button>

              </div>

            </div>

          </section>


          {/* ===================================
              CONTROLS
              =================================== */}

          <section className="fg-panel controls-panel">

            <div className="fg-panel-title">
              CONTROLS
            </div>

            <div className="vertical-controls">

              <div className="vertical-control">

                <div className="control-number">
                  1
                </div>

                <input
                  type="range"
                  min="1"
                  max="10"
                  value={amplitude}
                  onChange={(e) =>
                    setAmplitude(Number(e.target.value))
                  }
                />

                <strong>
                  Amplitude
                </strong>

              </div>


              <div className="vertical-control">

                <div className="control-number">
                  2
                </div>

                <input
                  type="range"
                  min="1"
                  max="10"
                  value={frequency}
                  onChange={(e) =>
                    setFrequency(Number(e.target.value))
                  }
                />

                <strong>
                  Frequency
                </strong>

              </div>


              <div className="vertical-control">

                <div className="control-number">
                  3
                </div>

                <input
                  type="range"
                  min="0"
                  max="360"
                  value={phase}
                  onChange={(e) =>
                    setPhase(Number(e.target.value))
                  }
                />

                <strong>
                  Phase
                </strong>

              </div>

            </div>

          </section>

        </div>

      </main>

    </div>
  );
}

export default FunctionGenerator;