import { useState } from "react";

import bietLogo from "../assets/biet-logo.png";
import virtualLabLogo from "../assets/virtual-lab-logo.png";

function StudentDashboard() {
  const [selectedLab, setSelectedLab] = useState(null);

  const labs = [
    {
      id: 1,
      name: "Basic Electronics Lab",
      icon: "⚡",
      description: "Fundamentals of electronic circuits and components.",
    },
    {
      id: 2,
      name: "Digital Electronics Lab",
      icon: "▣",
      description: "Digital logic, gates, flip-flops and counters.",
    },
    {
      id: 3,
      name: "Network Theory Lab",
      icon: "⌁",
      description: "Analysis of electrical and electronic networks.",
    },
    {
      id: 4,
      name: "Electronic Devices Lab",
      icon: "◉",
      description: "Study of diodes, transistors and semiconductor devices.",
    },
    {
      id: 5,
      name: "Communication Lab",
      icon: "📡",
      description: "Study of analog and digital communication systems.",
    },
    {
      id: 6,
      name: "Signal & System Lab",
      icon: "〰",
      description: "Analysis of signals and systems.",
    },
    {
      id: 7,
      name: "Analog Circuit Lab",
      icon: "∿",
      description: "Study and analysis of analog electronic circuits.",
    },
    {
      id: 8,
      name: "Integrated Circuit Lab",
      icon: "▦",
      description: "Study of integrated circuits and their applications.",
    },
    {
      id: 9,
      name: "Digital Signal Processing Lab",
      icon: "〽",
      description: "Digital signal processing, filtering and transforms.",
    },
  ];

  const integratedCircuitExperiments = [
    "Design the following using Op-Amp",
    "Study and design Log and antilog amplifiers",
    "Voltage to current and current to voltage converters",
    "Second order filters using operational amplifier",
    "Realization of Band pass filter with unit gain of pass band from 1 KHz to 12 KHz",
    "Study and design voltage comparator and zero crossing detectors",
    "Function generator using operational amplifier",
    "Design and construct astable multivibrator using IC 555",
    "Design and construct monostable multivibrator using IC 555",
    "Implement Schmitt Trigger Circuit using IC 555",
    "Implement voltage-controlled oscillator using IC566",
    "Study and design ramp generator using IC 566",
  ];

  const handleLabClick = (lab) => {
    setSelectedLab(lab);
  };

  const handleBack = () => {
    setSelectedLab(null);
  };

  return (
    <div className="dashboard-page">

      {/* HEADER */}

      <header className="dashboard-header">

        <img
          src={bietLogo}
          alt="BIET Jhansi"
          className="dashboard-biet-logo"
        />

        <div className="dashboard-title">
          <h1>BIET Jhansi</h1>
          <p>Virtual Electronics Laboratory</p>
        </div>

        <div className="dashboard-right">

          <img
            src={virtualLabLogo}
            alt="Virtual Electronics Laboratory"
            className="dashboard-lab-logo"
          />

          <button className="logout-button">
            Logout
          </button>

        </div>

      </header>


      {/* MAIN CONTENT */}

      <main className="dashboard-content">

        {!selectedLab ? (

          /* AVAILABLE LABS */

          <>
            <div className="welcome-section">
              <h2>Student Dashboard</h2>

              <p>
                Welcome to the Virtual Electronics Laboratory
              </p>
            </div>

            <section className="labs-section">

              <h3>Available Labs</h3>

              <p className="section-description">
                Select a laboratory to view its available experiments.
              </p>

              <div className="labs-grid">

                {labs.map((lab) => (

                  <div
                    key={lab.id}
                    className="lab-card"
                    onClick={() => handleLabClick(lab)}
                  >

                    <div className="lab-icon">
                      {lab.icon}
                    </div>

                    <div className="lab-info">

                      <h4>{lab.name}</h4>

                      <p>
                        {lab.description}
                      </p>

                    </div>

                    <button
                      className="open-lab-button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleLabClick(lab);
                      }}
                    >
                      Open Lab →
                    </button>

                  </div>

                ))}

              </div>

            </section>
          </>

        ) : (

          /* SELECTED LAB */

          <section className="experiments-page">

            <button
              className="back-button"
              onClick={handleBack}
            >
              ← Back to Available Labs
            </button>


            <div className="selected-lab-header">

              <div className="selected-lab-icon">
                {selectedLab.icon}
              </div>

              <div>
                <h2>{selectedLab.name}</h2>

                <p>
                  Available Experiments
                </p>
              </div>

            </div>


            {selectedLab.name === "Integrated Circuit Lab" ? (

              /* INTEGRATED CIRCUIT LAB TABLE */

              <div className="experiments-table-container">

                <table className="experiments-table">

                  <thead>
                    <tr>
                      <th>S. No.</th>
                      <th>Experiment</th>
                      <th>Action</th>
                    </tr>
                  </thead>

                  <tbody>

                    {integratedCircuitExperiments.map(
                      (experiment, index) => (

                        <tr key={index}>

                          <td className="serial-number">
                            {index + 1}
                          </td>

                          <td className="experiment-name">
                            {experiment}
                          </td>

                          <td className="experiment-action">

                          <button
                            className="perform-button"
                            onClick={() => {
                              if (experiment === "Function generator using operational amplifier") {
                                window.location.href = "/experiment/function-generator";
                              }
                            }}
                          >
                            Perform →
                          </button>

                          </td>

                        </tr>

                      )
                    )}

                  </tbody>

                </table>

              </div>

            ) : (

              /* OTHER LABS */

              <div className="experiments-empty">

                <div className="empty-icon">
                  🔬
                </div>

                <h3>
                  No Experiments Published Yet
                </h3>

                <p>
                  Experiments for this laboratory will appear
                  here once they are published by the administrator.
                </p>

              </div>

            )}

          </section>

        )}

      </main>

    </div>
  );
}

export default StudentDashboard;